=== Hanoi Tower ===
 
Contributors: Igvar
Tags: Game, Hanoi Tower, drag & drop
Requires at least: 6.0
Tested up to: 6.6.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A WordPress plugin which allow users play Hanoi Tower game on the site page.
 
== Description ==
 
This plugin allow to place shortcode with Hanoi Tower game to any of page of your site.
 
== Installation ==
 
1. Upload the plugin folder to your /wp-content/plugins/ folder.
2. Go to the **Plugins** page and activate the plugin.
 
== Frequently Asked Questions ==
 
= How to use plugin after installation =
Activate the plugin and insert shortcode [hanoi-tower] to any of your site page and save it.

= How to uninstall the plugin? =
Simply deactivate and delete the plugin. 
 
== Screenshots ==

1. How the game look on the page.
 
== Changelog ==
= 1.0 =
* Plugin released.