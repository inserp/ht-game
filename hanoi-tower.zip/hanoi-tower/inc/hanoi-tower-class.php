<?php
namespace HNTW;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Game_HNTW' ) ) {
    class Game_HNTW {

        private static $instance = null;
        private static $initial_game_state = [
            'pegs' => [
                [7, 6, 5, 4, 3, 2, 1],  // All disks start on peg 1
                [],                     // Peg 2 is empty
                []                      // Peg 3 is empty
            ],
            'completed' => false
        ];

        private function __construct()
        {

            if (!session_id()) {
                session_start();
            }

            if (!isset($_SESSION['game'])) {
                $_SESSION['game'] = self::$initial_game_state;
            }

            add_action( 'rest_api_init', [ $this, 'hntw_register_rest_routes' ] );
            add_shortcode( 'hanoi-tower', [ $this, 'hntw_shortcode' ] );
        }

        public static function hntw_get_instance(): mixed
        {
            if ( null == self::$instance ) {
                self::$instance = new self;
            }
            return self::$instance;
        }

        public function hntw_register_rest_routes(): void
        {
            register_rest_route( 'hntw/v1', '/game-state', [
                'methods'  => 'GET',
                'callback' => [ $this, 'hntw_get_game_state' ],
                'permission_callback' => '__return_true',
            ]);

            register_rest_route( 'hntw/v1', '/new-game', [
                'methods'  => 'GET',
                'callback' => [ $this, 'hntw_new_game' ],
                'permission_callback' => '__return_true',
            ]);

            register_rest_route( 'hntw/v1', '/move-disk', [
                'methods'  => 'POST',
                'callback' => [ $this, 'hntw_move_disk' ],
                'args'     => [
                    'from' => [
                        'required' => true,
                        'validate_callback' => [ $this, 'is_valid_peg' ]
                    ],
                    'to' => [
                        'required' => true,
                        'validate_callback' => [ $this, 'is_valid_peg' ]
                    ],
                ],
                'permission_callback' => '__return_true',
            ]);
        }

        private function hntw_is_game_completed() : bool 
        {
            // If all disks are on the last peg, the game is finished
            return isset($_SESSION['game']['pegs'][2]) && count($_SESSION['game']['pegs'][2]) === 7;
        }

        public function hntw_get_game_state() : array 
        {
            return [
                'pegs' => $_SESSION['game']['pegs'],
                'completed' => self::hntw_is_game_completed()
            ];
        }

        public function hntw_new_game()
        {
            session_destroy();
            return [
                'completed' => self::hntw_is_game_completed()
            ];
        }

        // Function to handle moves between pegs
        public function hntw_move_disk( \WP_REST_Request $request ): \WP_REST_Response
        {
            $from = (int) $request->get_param('from');
            $to = (int) $request->get_param('to');

            // Check if the game is already completed
            if ($_SESSION['game']['completed']) {
                return new \WP_REST_Response( ['error' => 'Game already completed!'], 400 );
            }

            // Validate the move
            if (!self::hntw_is_valid_move($from, $to)) {
                return new \WP_REST_Response( ['error' => 'Invalid move!'], 400);
            }

            // Move the disk
            $disk = array_pop($_SESSION['game']['pegs'][$from]);
            array_push($_SESSION['game']['pegs'][$to], $disk);

            // Check if the game is completed after the move
            if (self::hntw_is_game_completed()) {
                $_SESSION['game']['completed'] = true;
            }

            return new \WP_REST_Response( [
                'pegs' => $_SESSION['game']['pegs'],
                'completed' => $_SESSION['game']['completed']
            ] );
        }

        // Function to validate the move
        private function hntw_is_valid_move(int $from, int $to): bool
        {
            // Peg indices must be between 0 and 2
            if ($from < 0 || $from > 2 || $to < 0 || $to > 2) {
                return false;
            }

            // There must be a disk to move from the "from" peg
            if (empty($_SESSION['game']['pegs'][$from])) {
                return false;
            }

            // You cannot move a disk to a non-empty peg if the disk is larger than the top disk on the "to" peg
            if (!empty($_SESSION['game']['pegs'][$to]) &&
                end($_SESSION['game']['pegs'][$from]) > end($_SESSION['game']['pegs'][$to])) {
                return false;
            }

            return true;
        }

        public function hntw_shortcode(): string
        {
            wp_enqueue_script('jquery');
            //wp_enqueue_script( 'query-builder', HNTW_DIR_URL . 'assets/js/query-builder.standalone.js', 'jquery' , false, true );
            wp_enqueue_script( 'hanoi-tower', HNTW_DIR_URL . 'assets/js/script.js', 'jquery' , 1.0, true );
			wp_localize_script( 'hanoi-tower', 'hanoi_tower_object', [
                'rest_url' => get_rest_url(null, '/hntw/v1/')
            ]);
            //wp_enqueue_style( 'query-builder', HNTW_DIR_URL . 'assets/css/query-builder.css' );
            wp_enqueue_style( 'hanoi-tower', HNTW_DIR_URL . 'assets/css/styles.css' );
            $html = '<div id="hanoi-tower">
                <div class="peg"></div>
                <div class="peg"></div>
                <div class="peg"></div>
            </div><div id="turn"></div><div id="new-game">New game</div>';
            return $html;
        }

        public function is_valid_peg($param): bool
        {
            if(is_numeric( $param )){
                if($param >= 0 && $param < 3){
                    return true;
                }
            }
            return false;
        }

        private function hntw_debug($item, $text = ''): void
        {
            if(!empty($text)) $text = $text . "\n";
            file_put_contents( HNTW_DIR_PATH . '/debug.log', "\n" . $text, FILE_APPEND);
            file_put_contents( HNTW_DIR_PATH . '/debug.log', print_r($item, true), FILE_APPEND);
        }
    }

    Game_HNTW::hntw_get_instance();

}