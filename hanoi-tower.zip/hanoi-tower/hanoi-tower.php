<?php
/**
 * Plugin Name:        Hanoi Tower
 * Description:        Hanoi Tower Game.
 * Author:             Ihar Dounar
 * Author URI:         https://www.linkedin.com/in/ihar-dounar/
 * Developer:		   Ihar Dounar
 * Developer URI:	   https://www.upwork.com/freelancers/igvar
 * Requires at least:  6.2
 * Text Domain:        hanoi-tower
 * Domain Path:        /languages
 * Version:            1.0
 * License:            GPL-2.0-or-later
 *
 * @package         hanoi-tower
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*************************************************************************
* Constants
************************************************************************/
define( 'HNTW_DIR_PATH', __DIR__ );
define( 'HNTW_DIR_URL', plugin_dir_url(__FILE__));

/*************************************************************************
 * Requires - core
 ************************************************************************/
require_once HNTW_DIR_PATH . '/inc/hanoi-tower-class.php';